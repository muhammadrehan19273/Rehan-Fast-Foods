REHAN FAST FOODS — FREE GITHUB PAGES + FIREBASE FIRESTORE SETUP

Files:
- index.html: public storefront. Loads active products from Firestore.
- admin.html: Firebase email/password sign-in; product create/edit/delete; uses image URLs (no Firebase Storage required).
- firestore.rules: Firestore security rules for products collection.
- README_SETUP.txt: setup notes.

SETUP
1. Upload index.html and admin.html to the ROOT of your GitHub repository.
2. Firebase Console > Firestore > Rules: publish the contents of firestore.rules.
3. Authentication > Sign-in method: enable Email/Password and create your admin user.
4. Authentication > Settings > Authorized domains: add YOUR-USERNAME.github.io (hostname only).
5. Enable GitHub Pages for the repository.
6. Open https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/admin.html to sign in.

PRODUCT PHOTOS WITHOUT STORAGE
- Easiest: paste a direct, publicly accessible image URL in the admin form.
- Or upload image files to your GitHub repo in a folder such as images/ and enter a relative URL like images/burger.jpg.
- If using relative image paths, note the public storefront's path resolution depends on the repository URL; for project Pages, use ./images/burger.jpg.
- No Firebase Storage is used, so no Storage billing upgrade is needed for this version.

PRODUCTS
Firestore collection: products.
Fields: name (string), price (number), category (string), description (string), image (string), active (boolean).
Public store queries products where active == true.

LIMITATIONS
- Cart is a demo only; checkout does not send real orders.
- No payment, delivery integration, or order management backend.
- Firebase web config is client-side configuration, not a private service credential. Never publish passwords or service-account keys.
